/**
 * Created by ep-react on 14.06.17.
 */

var express    = require('express');
var app        = express();
var bodyParser = require('body-parser');
var cors       = require('cors');

// to parse our posts
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// dealing with cors (u know localhost:3000 & localhost:4200 is a different domains.. so if you don't wan't to use
// --disable-web-security, use cors lib. it says "yes" for all OPTIONS from localhost:4200)
var originsWhitelist = ['http://localhost:4200'];
var corsOptions = {
    origin: function(origin, callback){
        var isWhitelisted = originsWhitelist.indexOf(origin) !== -1;
        callback(null, isWhitelisted);
    },
    credentials:false
}
app.use(cors(corsOptions));

var tasks = require('./tasks-mock')

// routing
// @TODO yes, I know that keeping routing in separate dir is a better way. I use only one file for simplicity
// @TODO also I don't use forever/pm2 etc for simplicity
// @TODO also I do validations manually without libs and models. In real app ORM models do part of validation work
var router = express.Router();
router.get('/task', function(req, res) {
    // about copying without using jsonlint: http://pix.toile-libre.org/upload/original/1497446533.png
    // different symbols add to me problems with dates on client side
    res.json(tasks);
});
router.post('/task/create', function(req, res) {
    // @TODO validations
    tasks.push(req.body);
    res.json({
        message: 'stub ok'
    });
});
router.post('/task/update', function(req, res) {
    res.json({
        message: 'stub ok'
    });
});
router.get('/task/destroy/:id', function(req, res) {
    res.json({
        message: 'stub ok'
    });
});
app.use('/', router);

// run app
var port = process.env.PORT || 3000;
app.listen(port);
console.log('Server listen on port ' + port);
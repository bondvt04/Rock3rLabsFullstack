/**
 * Created by ep-react on 14.06.17.
 */

module.exports = [
    {
        "title": "Task 1",
        "description": "sleep",
        "owner": 6,
        "priority": 1,
        "dueDate": "2014-10-01",
        "creator": 6,
        "taskStatus": 1,
        "createdAt": "2014-02-08T06:50:51.479Z",
        "updatedAt": "2014-02-08T06:50:51.479Z",
        "id": 2
    },
    {
        "title": "Task 2",
        "description": "Task2",
        "owner": 6,
        "priority": 2,
        "dueDate": "2014-10-02",
        "creator": 6,
        "taskStatus": 1,
        "createdAt": "2014-02-08T16:30:35.115Z",
        "updatedAt": "2014-02-08T16:30:35.115Z",
        "id": 3
    },
    {
        "title": "Task 2",
        "description": "Task2",
        "owner": 7,
        "priority": 2,
        "dueDate": "2014-10-03",
        "creator": 6,
        "taskStatus": 1,
        "createdAt": "2014-02-08T16:30:46.732Z",
        "updatedAt": "2014-02-08T16:30:46.732Z",
        "id": 4
    }
];
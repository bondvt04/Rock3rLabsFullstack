import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpClient } from './services/httpClient.service';
import { TasksService } from './services/tasks.service';
import { TasksSortPipe } from './pipes/tasks-sort.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    TasksSortPipe
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule
  ],
  providers: [HttpClient, TasksService],
  bootstrap: [AppComponent]
})
export class AppModule { }

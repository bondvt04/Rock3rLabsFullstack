import { Component, OnInit } from '@angular/core';
import { TasksService } from "./services/tasks.service";

// @TODO in real app I use module named "screens" and components in it. Using app.component for logic generally bad idea..
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  // @TODO use model instead of <any>
  public tasks: Array<any>;

  public sortString = 'priority_reversed';

  constructor(
    private tasksService: TasksService
  ) {}

  getTasks() {
    this.tasksService.getTasks()
      .subscribe(res => {
        this.tasks = res
      })
  }

  addTask(form, event) {
    event.preventDefault();
    event.stopPropagation();

    if (!form.valid) {
      return;
    }
    this.tasksService
      .createTask(form.value)
      .subscribe(res => {
        // @TODO use response
        this.getTasks();
        form.reset();
      }, error => {
        console.error(error);
      })
  }

  ngOnInit() {
    this.getTasks();
  }
}

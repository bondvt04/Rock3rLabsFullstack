import { Injectable } from '@angular/core';

import { Observable } from "rxjs";

import { HttpClient } from './httpClient.service';

import { environment } from "../../environments/environment";

@Injectable()
export class TasksService {

  private url = environment.api.endpoint;

  constructor(
    private http: HttpClient
  ) {}

  getTasks(): Observable<any> {
    return this.http.get(`${this.url}/task`);
  }

  editTask(task): Observable<any> {
    // @TODO maybe better way is POST /task/:id
    return this.http.post(`${this.url}/task/update`, task)
  }

  createTask(task): Observable<any> {
    return this.http.post(`${this.url}/task/create`, task);
  }

  removeTask(id): Observable<any> {
    // @TODO why GET instead of DELETE?
    return this.http.get(`${this.url}/task/destroy/${id}`)
  }

}

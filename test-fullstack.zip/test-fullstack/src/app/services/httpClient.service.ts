import {Injectable} from '@angular/core';
import {Http, Headers} from '@angular/http';

import { Observable } from "rxjs";
import 'rxjs/Rx';

@Injectable()
export class HttpClient {
  constructor(private http: Http) {}

  get(url: string): Observable <any> {
    let headers = new Headers();

    return this.http.get(url, {
      headers: headers
    })
      .map(response => {
        return response.text().toString() === 'OK' || response.headers.get('Content-type') === 'text/plain' ? response.text() : response.json();
      })
      .catch(this.handleError);
  }

  post(url: string, data): Observable <any> {
    let headers = new Headers();

    return this.http.post(url, data, {
      headers: headers
    })
    .map(response => {
      return response.text().toString() === 'OK' || response.headers.get('Content-type') === 'text/plain' ? response.text() : response.json();
    })
    .catch(this.handleError);
  }

  put(url: string, data): Observable <any> {
    let headers = new Headers();

    return this.http.put(url, data, {
      headers: headers
    })
    .map(response => {
      return response.text().toString() === 'OK' || response.headers.get('Content-type') === 'text/plain' ? response.text() : response.json();
    })
    .catch(this.handleError);
  }

  delete(url: string): Observable <any> {
    let headers = new Headers();

    return this.http.delete(url, {
      headers: headers
    })
    .map(response => {
      return response.text().toString() === 'OK' || response.headers.get('Content-type') === 'text/plain' ? response.text() : response.json();
    })
    .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

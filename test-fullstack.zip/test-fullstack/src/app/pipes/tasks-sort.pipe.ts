/**
 * Created by ep-react on 14.06.17.
 */

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tasksSort'
})
export class TasksSortPipe implements PipeTransform {

  private sortedBy: string;
  private isReversed: boolean;

  private sort_by(field, reverse, primer){
    const key = primer ?
      function(x) {return primer(x[field])} :
      function(x) {return x[field]};

    reverse = !reverse ? 1 : -1;

    return function (a, b) {
      return a = key(a), b = key(b), reverse * (((a > b) as any) - ((b > a) as any));
    }
  }

  transform(tasks: Array<any>, sortString?: string): any {
    const that = this;
    if (tasks == null) {
      return null;
    }

    function check(field) {
      that.isReversed = that.sortedBy === field ? !that.isReversed : false;
      that.sortedBy = field;
      switch (field) {
        case 'title':
          return tasks.sort(that.sort_by('title', false, function(a){ return a ? a.toUpperCase() : null}));
        case 'title_reversed':
          return tasks.sort(that.sort_by('title', true, function(a){ return a ? a.toUpperCase() : null}));
        case 'dueDate':
          return tasks.sort(that.sort_by('dueDate', false, function(a){return new Date(a)}));
        case 'dueDate_reversed':
          return tasks.sort(that.sort_by('dueDate', true, function(a){return new Date(a)}));
        case 'priority':
          return tasks.sort(that.sort_by('priority', false, parseInt));
        case 'id_priority':
          return tasks.sort(that.sort_by('priority', true, parseInt));
        default:
          return tasks
      }
    }

    return check(sortString);

  }
}

/**
 * Created by ep-react on 14.06.17.
 */

// @TODO implement model for type validation purposes and duedate calculations (instead of doing it in view)

import { TestFullstackPage } from './app.po';

describe('test-fullstack App', () => {
  let page: TestFullstackPage;

  beforeEach(() => {
    page = new TestFullstackPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
